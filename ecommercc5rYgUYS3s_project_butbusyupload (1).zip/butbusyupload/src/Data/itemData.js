const data = [
  {
    id: 1,
    name: 'T-shirt',
    price: 100,
    category: 'mensFashion',
    img: "https://fakestoreapi.com/img/81fPKd-2AYL._AC_SL1500_.jpg",
  },
  {
    id: 2,
    name: 'Pants',
    price: 200,
    category: 'jewelery',
    img: "https://fakestoreapi.com/img/61U7T1koQqL._AC_SX679_.jpg",
  },
  {
    id: 3,
    name: 'Shoes',
    price: 300,
    category: 'electronics',
    img: "https://fakestoreapi.com/img/71kWymZ+c+L._AC_SX679_.jpg",
  },
  {
    id: 4,
    name: 'Hat',
    price: 400,
    category: 'womensFashion',
    img: "https://fakestoreapi.com/img/61mtL65D4cL._AC_SX679_.jpg",
  },
  {
    id: 5,
    name: 'Socks',
    price: 500,
    category: 'women',
    img: "https://fakestoreapi.com/img/81XH0e8fefL._AC_UY879_.jpg",
  },
];

export default data;
